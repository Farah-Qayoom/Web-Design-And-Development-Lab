<?php

$host     = "localhost";
$dbUser   = "root";
$dbPass   = "";
$dbName   = "student_db";


$conn = new mysqli($host, $dbUser, $dbPass, $dbName);


if ($conn->connect_errno) {
    die("❌ Database Connection Failed: " . $conn->connect_error);
}
?>
