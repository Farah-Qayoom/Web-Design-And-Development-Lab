<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $studentName  = trim($_POST['name']);
    $studentEmail = trim($_POST['email']);
    $studentCourse = trim($_POST['course']);

    $insert = "INSERT INTO students (name, email, course) VALUES ('$studentName', '$studentEmail', '$studentCourse')";
    
    if ($conn->query($insert)) {
        echo "<script>alert('✅ Student has been added successfully!'); window.location='view_students.php';</script>";
    } else {
        echo "Database Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Student Record</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
    <h2>➕ Register New Student</h2>
    <form action="" method="post">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email Address" required>
        <input type="text" name="course" placeholder="Course Name" required>
        <button type="submit">Save Student</button>
    </form>
    <a href="index.php" class="back-link">⬅ Return to Dashboard</a>
</div>
</body>
</html>
