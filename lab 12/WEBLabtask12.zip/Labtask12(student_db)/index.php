<?php include("config.php"); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Management Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>⚙️ Management Dashboard</h1>
        <div class="nav">
            <a href="add_student.php">➕ Add Student</a>
            <a href="view_students.php">👨‍🎓 Manage Students</a>
        </div>
    </div>
</body>
</html>