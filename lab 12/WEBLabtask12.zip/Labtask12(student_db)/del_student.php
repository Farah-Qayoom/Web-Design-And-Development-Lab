<?php
include("config.php");

if (!empty($_GET['id'])) {
    $studentId = intval($_GET['id']); 
    $deleteQuery = "DELETE FROM students WHERE id = $studentId";

    if ($conn->query($deleteQuery)) {
        echo "<script>alert('✅ Student record removed successfully!'); window.location='view_students.php';</script>";
    } else {
        echo "❌ Failed to delete record: " . $conn->error;
    }
}
?>
