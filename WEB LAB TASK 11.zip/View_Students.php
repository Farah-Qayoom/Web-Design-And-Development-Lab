<?php
require_once("config.php");
$query = "SELECT * FROM students ORDER BY id DESC";
$data = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Management</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
    <h2>👨‍🎓 Student Records</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Course</th>
                <th>Date Registered</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            <?php while($student = $data->fetch_assoc()) { ?>
            <tr>
                <td><?= $student['id']; ?></td>
                <td><?= $student['name']; ?></td>
                <td><?= $student['email']; ?></td>
                <td><?= $student['course']; ?></td>
                <td><?= $student['
