<?php
include("config.php");

$query = "SELECT * FROM students ORDER BY id DESC";
$data = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Management</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
    <h2>👨‍🎓 Student Management</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Email Address</th>
                <th>Course</th>
                <th>Joined On</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
        <?php while($student = $data->fetch_assoc()){ ?>
            <tr>
                <td><?= $student['id'] ?></td>
                <td><?= $student['name'] ?></td>
                <td><?= $student['email'] ?></td>
                <td><?= $student['course'] ?></td>
                <td><?= $student['reg_date'] ?></td>
                <td>
                    <a class="action-edit" href="edit_student.php?id=<?= $student['id'] ?>">✏ Edit</a>
                    <a class="action-delete" href="delete_student.php?id=<?= $student['id'] ?>" onclick="return confirm('Do you really want to remove this student?')">🗑 Delete</a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
    <a class="back-btn" href="index.php">⬅ Back to Dashboard</a>
</div>
</body>
</html>
